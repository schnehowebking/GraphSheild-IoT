# External aggregation correction supplement

This supplement accompanies the v3 highlighted manuscript. It corrects source/time fragmentation and external block interpretation identified after release v1.0.0. Historical evidence is retained. It does not retune a detector, source gate or confirmatory experiment.

Extract this ZIP into a **separate copy** of the v1.0.0 repository. It supplies corrected scripts/tests, results and FINAL_ARTIFACT_MAP.md. Do not run the historical source MANIFEST verifier against the patched copy and mistake expected source differences for corruption; the supplement has its own manifest. Keep the original v1.0.0 checkout for historical replay.

Use Python 3.13 and `requirements-lock.txt` from v1.0.0. First extract/replay historical evidence:

```bash
python scripts/verify_public_release.py --output results/public_replay_v1
python -m pytest tests/test_external_source_time_correction.py tests/test_process_external_raw_datasets.py -q
python scripts/verify_external_correction_v2.py --results results/external_audit_correction_v2 --deployment results/public_replay_v1/extracted/reviewer_revision_v1/deployment
```

To independently regenerate the correction, obtain the consumed raw sources using the historical source fingerprints and run:

```bash
python scripts/correct_external_audit_v2.py --raw-root /path/to/datasetsforexternalaudit --evidence results/public_replay_v1/extracted --output results/external_audit_correction_REPRO
python scripts/verify_external_correction_v2.py --results results/external_audit_correction_REPRO --deployment results/public_replay_v1/extracted/reviewer_revision_v1/deployment
```

The script detects affected source files from duplicate source/time keys, verifies their hashes, reprocesses them from raw records, retains unaffected rows with provenance, reapplies the frozen controlled model, and recomputes all external summaries. One CIC file and eight TON files were reprocessed (3,001,878,491 bytes); IoT-23 processing was retained. The 677 extra fragmented rows disappear; consumed raw-row, packet and byte totals remain conserved. Source cardinality and entropy are recomputed from raw occurrence counts, never by merging aggregate entropies.

Source-file boundaries do not establish independent capture sessions. The 2,000-draw ranges (seed 20260928) are descriptive sensitivity summaries for the observed block mixture. The block map and positive-class support are included. Zero-denominator bootstrap ratios retain the disclosed legacy zero convention. No target labels influence model fitting or threshold selection. All previous external results remain historical artifacts.

The full local test suite after the correction passed 81 tests with two optional GNN skips. This did not repeat OVS traffic collection. See FINAL_ARTIFACT_MAP.md for the exact final manuscript evidence streams.

Before public submission, publish this supplement with the revised documents or a new versioned repository release and update the public citation accordingly. The v1.0.0 DOI alone does not contain these corrections. Repository/Zenodo license metadata must be reconciled by the rights holder; this supplement does not change the repository license or select a new license. Preserve stable provenance for historical v1.0.0 and do not silently replace its evidence.
