# Final manuscript artifact map

The v3 highlighted manuscript retains historical v1.0.0 controlled and OVS evidence and replaces only the external Table 8/Figure 9 result stream. The historical release is commit f426137, DOI 10.5281/zenodo.23238932. That DOI does not identify this correction supplement.

After `scripts/verify_public_release.py --output results/public_replay_v1`, paths in the historical column are relative to `results/public_replay_v1/extracted`. Correction paths are relative to this supplement. Raw collection and offline replay are distinct operations.

| Manuscript item | Exact evidence source |
|---|---|
| Table 2; Figure 2 | `reviewer_revision_v1/temporal_fold_metrics.csv`, `temporal_aggregate_metrics.json`, `temporal_confidence_intervals.csv`, `temporal_fold_definitions.csv` |
| Figures 3 and 4 | `reviewer_revision_v1/temporal_predictions.csv`; ROC and precision-recall from saved labels/probabilities |
| Table 3; Figure 5 | `reviewer_revision_v1/topology_comparison.csv`, `topology_predictions.csv` |
| Table 4; Figure 6 | `actual_ovs_kali_safety_v3/safety_analysis/safety_summary_with_ci.csv` and `paired_service_differences.csv`; same paths under `actual_ovs_ubuntu_safety_v3`; row source `safety_window_records.csv` |
| Source targeting coverage | Each host's `safety_analysis/safety_window_records.csv`, grouped by setting and attack phase; `selected_action == RATE_LIMIT` gives 27/180 Kali and 30/180 Ubuntu per audit arm |
| Table 5; Figure 7 | `reviewer_revision_v1/flash_crowd_comparison.csv`; six scenario partitions of the same 438 medium-profile rows in `topology_predictions.csv`, not another collection |
| Table 6; Figure 8 | `reviewer_revision_v1/audit_scalability.csv`, `audit_record_timings.csv`; local serial append timing |
| Table 7 | `reviewer_revision_v1/rollback_verification.json`, `audit_verification.json`, both OVS `verification_v3.json` and archived rule/meter records; configured timeout and removal, no passive expiry certification |
| Table 8; Figure 9 | **Correction:** `results/external_audit_correction_v2/external_table_publication.csv`, `external_predictions.csv`, `external_confidence_intervals.csv`, `external_block_map.csv`, `external_block_support.csv`, `correction_manifest.json` |
| Table 9; Figure 10 | `reviewer_revision_v1/policy_comparison.csv`, `policy_pairwise_statistics.csv`, `policy_predictions.csv`, per-policy feature/model metadata |
| Figure 1 | Conceptual evaluated-path diagram; `sdn.py`, `reviewer_revision/core.py`, `source_selector.py`, `policies.py`, detector/threshold/source-policy configs. No additional numeric experiment |

**Historical filenames are not manuscript identity.** Controlled-pipeline exports `tables/table_4.csv` (controller-code timing) and `tables/table_8.csv` (compact external inputs) do not reproduce the current manuscript's actual OVS Table 4 and corrected raw-derived Table 8. Follow this map, not the historical numbers in filenames. Old source-time segmented external outputs remain available for provenance and are superseded for final Table 8.

Binary and attack-specific external views overlap. The corrected distinct binary row count is 358,791; do not add subset rows to it. Ranges are descriptive block-resampling sensitivity, not population confidence intervals, because capture/session independence is unestablished.
