# OVS safety analysis

Receiver `end.sum_received` fields only; missing measurements stay undefined. Classification FPR is not benign-service damage. Target selected in window t is associated with service in t+1; the last selection has no subsequent measured window. Means are means of complete-trial means; CIs resample trials (2000 draws, fixed seed). Paired differences resample within-seed trial differences. No mitigation reference permits schedule-matched contrasts, not identical-packet counterfactuals.
