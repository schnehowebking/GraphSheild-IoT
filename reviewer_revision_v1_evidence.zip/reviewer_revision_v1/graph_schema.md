# Graph schema and causal construction

The existing simulator supplies source IP, destination IP, switch ID, packets, bytes, flows
and event timestamps. Destination IP is a service proxy: transport ports/service identity are
unavailable, and the default simulator has one destination. No extra topology links are invented.
These experiments fit classifiers to explicit graph summaries; they are not trained GNNs.

At the end of each 5-second window, all events with timestamp < window end are observable.
The current graph contains typed source and service nodes joined by observed interactions.
Edges aggregate packet counts. Bipartite features include edge count, node counts, source/service
degrees and edge packet weights. The switch variant additionally constructs observed
source-switch and switch-service edges and counts observed three-node paths. These are observed
attachments, not verified physical network routes. A local switch packet-share feature locates
the decision window within the global graph at that window close.

Controller context adds event arrival gaps, flow-count variation and active-switch count, all
computed from the input event stream. It excludes the old simulator's label-dependent latency
formula. CPU load and real controller RTT are unavailable and are not invented.

Temporal edges keep only past events within a 30-second history, reset at each independent run.
Features include historical edge count, new/returning edge fractions and sum of packet weights
times exp(-(decision_time-event_time)/15 seconds). Current edges are added to history only after
that timestamp batch is scored. No future event or future normalization statistic is inspected.
Normalized edge weights use packet_count_on_edge / total_packets_in_current_window; their max
and entropy are features. Edge packet rate uses count/5 seconds. This normalization is local
and causal, not a min/max fit across the test set.

Exact input feature lists are in policy_feature_manifest.json; per-fold hyperparameters, seeds,
training/validation/test sizes, thresholds, model hashes and inference time are in
policy_configuration.json and the model directories. Graph construction time is distinct from
classifier inference time; the reported batch inference time does not include graph building.
