# Revised claim to artifact map

- Table 2: `temporal_fold_metrics.csv` (copy: `tables/table_2.csv`).
- Table 3: `topology_comparison.csv` (copy: `tables/table_3.csv`).
- Table 4: `live_trial_summary_with_ci.csv` (copy: `tables/table_4.csv`).
- Table 5: `flash_crowd_comparison.csv` (copy: `tables/table_5.csv`).
- Table 6: `audit_scalability.csv` (copy: `tables/table_6.csv`).
- Table 7: `rollback_verification.json` (copy: `tables/table_7.json`).
- Table 8: `external_comparison.csv` (copy: `tables/table_8.csv`).
- Table 9: `policy_comparison.csv` (copy: `tables/table_9.csv`).

Table 2 also needs temporal_aggregate_metrics.json, temporal_confidence_intervals.csv and temporal_fold_definitions.csv. Table 9 needs policy_pairwise_statistics.csv and the feature/configuration manifests. Table 4 must be titled controlled simulation with measured controller-method timings. Tables 6/7 cover local append/mode transitions, not network consensus or rule reversal.
