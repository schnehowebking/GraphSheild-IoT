# Threshold governance

configs/threshold_registry.json distinguishes a diagnostic raw 0.5 probability reference,
validation-selected operating thresholds, disabled runtime safety overrides, policy actions,
and fixed-transfer external diagnostics. Old 0.1316 and 0.4 values are not reused.

For each fitted model, all unique validation probabilities, zero, and nextafter(1,+inf) are
candidates. The latter permits no mitigation even when a probability is exactly one. Select
maximum validation F1 subject to FPR <= 0.05, breaking ties by higher recall, lower FPR and
then higher threshold. It is a validation constraint, not a guarantee on future/test FPR.
Validation partitions must contain both classes; passing a test partition fails. No objective
or hyperparameter is selected by looking at test performance.

Each model directory saves its full validation curve and a threshold_selection.json binding
the value to model/schema hashes, validation data hash/run IDs, objective, constraint, registry
hash and selection timestamp. The root files are copies for the predetermined deployment model.
The runtime loader verifies model and feature-schema hashes. The runtime uses its saved threshold
and unchanged probability, without the old rate/event score scaling. It uses NONE or RATE_LIMIT;
BLOCK is not supported by this revision's action evidence. Canonical /detect-window requests
cannot override thresholds. Legacy partial-window and flow endpoints are separate operating
modes and are not the completed-window evaluation evidence.

The registry's operating.selection_file points at the versioned deployment selection. To use
another reproduced output, copy the registry to a new file, point selection_file at that
output's deployment/threshold_selection.json, then set GRAPHSHIELD_THRESHOLD_REGISTRY to its
path. This selects an already validation-governed model/threshold pair rather than retuning
on test labels. Root canonical configuration describes the default release output.

External datasets receive the fixed deployment model and threshold without any target fitting,
calibration or threshold search. These results are diagnostic feature-compatible transfer;
their rate/exposure and aggregation semantics differ from controller windows. Legacy
external_split and combined_to_external_holdout rows used target validation and are not zero-shot.
No oracle/target-label-optimized result is presented as transfer in the revised tables.
