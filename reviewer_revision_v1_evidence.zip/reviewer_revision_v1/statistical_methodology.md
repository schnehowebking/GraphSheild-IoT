# Statistical methodology

The sampling unit is an independently seeded controlled simulation run. Within a run,
five-second decision windows are grouped by switch and destination. Windows on different
switches at the same time are correlated and are never counted as independent bootstrap units.
Whole runs are ordered in synthetic event time. Each fold uses expanding past training runs,
the next validation runs and subsequent test runs. Test runs never overlap between folds.
Earlier test runs may enter a later model's training set, as in forward chaining, but never
influence the model evaluating those runs. No temporal shuffle is used. All scenarios recur
within each run; this evaluates future runs of known scenarios, NOT unseen scenario classes.
Entire scenario episodes stay in a run. Scenario/phase IDs and raw address identities are
excluded from fitted features; graph node identities are used only for structural counts.

The default uses every permissible whole-run fold given the declared minimum training,
validation and test sizes. Fold count may be reduced explicitly; requesting unavailable folds
fails. The final chronological fold model is chosen for deployment before evaluating test scores.
Aggregate metrics pool disjoint out-of-sample predictions from the fold-specific models.

The 95% percentile bootstrap resamples whole (fold, test-run) clusters, preserving every window
within each sampled cluster. It does not resample duplicated windows as independent evidence
or mix a block across temporal boundaries. Seed and replicate count appear in every CI row.
Class-stratified window bootstrap is deliberately not used: it would break within-run dependence.
Both classes occur within the generated mixed-scenario runs. Shared training induces remaining
dependence between fold models; intervals are conditional on the fitted models and simulator,
not a full retraining bootstrap or a guarantee for field deployments. Few clusters and simulator
design limit inference even when the number of windows is large. Degenerate CIs are retained.

Precision with no predicted positives, recall/FNR with no attacks, FPR/benign damage with no
benign windows, and ROC-AUC with one class are undefined. PR-AUC means average precision
(stepwise area), and is undefined with no positives. Undefined values are null in JSON / blank
in CSV with an explicit reason; no NaN/Infinity JSON is emitted. F1 is computed as
2TP/(2TP+FP+FN) when its denominator is nonzero.

Benign damage is FP/(TN+FP), a false-mitigation decision rate; actual lost benign traffic is
not measured. Reward is a declared classification utility: TP +2, FN -2, FP -1.25, TN +0.2.
It is not measured packet recovery or a counterfactual action effect.

Policy comparisons pair the exact same test windows and resample the same whole-run clusters
for both policies. The reward difference uses mean per-window utility. Exact McNemar p-values
are provided only as diagnostics: their window-independence assumption fails here. Cluster CIs
are primary. No multiplicity-adjusted superiority claim is made.

Stress trials use independent seeds, and audit-on/off share the same saved input, seed, model,
threshold and warmup. Execution order alternates to reduce order effects. Trial-level summaries
include sample SD, mean, median, min, max, n and Student-t intervals. Paired differences use
Student-t intervals across per-trial differences. Timings are perf_counter measurements of
sdn.CompletedWindowController, including local audit append when enabled. These are controlled
simulation inputs executing actual local controller code, not live traffic, HTTP latency,
OpenFlow rule installation or Go audit consensus. Historical simulated controller_latency_ms
and throughput_mbps columns from the event generator are NEVER used as measured outcomes.
