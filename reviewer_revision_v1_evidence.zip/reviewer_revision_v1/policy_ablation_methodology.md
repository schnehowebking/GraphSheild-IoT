# Policy ablation methodology

The old Table 9 generator transformed a baseline probability for multiple named graph/RL
policies, used full test-set ranges for normalization, evaluated the last 96 windows (including
the old validation set), and consulted y==0 inside risk selection. That generator has been
retired; its results are preserved solely as historical evidence.

Each new graph classifier is fitted independently to its documented graph features using
training labels only; its operating threshold is chosen on validation only. The ML-window
baseline uses only the eight canonical features. Inference rejects extra columns (including
labels). Graph preprocessing receives an explicit observable allowlist, with neither labels nor
scenario IDs. The exact same untouched test windows are used for every policy in each fold.

The imitation-regularized classifier minimizes CE(y,p) + lambda CE(teacher_probability,p),
equivalently CE((y+lambda*teacher)/(1+lambda),p), with an L2 term of 0.001 in the normalized
objective. The teacher is the canonical random forest fitted on that fold's training data only.
lambda=0.25 is fixed in advance, and feature standardization is fitted on training only.
This is supervised distillation, not reinforcement learning or behavior-policy evaluation.

The temporal risk selector fits its own temporal graph classifier and applies the recorded
validation threshold plus a fixed requirement that 1-p <= 0.1. Rejected mitigation proposals
become NONE and are counted as abstentions. This is an uncalibrated probability safety heuristic,
not a conformal bound or a guarantee of maximum realized benign damage. No test labels enter it.

Contextual bandit and conservative offline RL results are WITHDRAWN, not synthesized. Existing
logs lack exploration probabilities and sufficiently supported action-conditioned outcomes.
The old next-row probability/packet-count differences do not identify mitigation effects, and
overlapping trajectory windows cross old split boundaries. A classification reward cannot repair
this. New logged trajectories with actions, propensities, episode boundaries and measured
outcomes are required before an honest bandit/OPE or conservative-RL evaluation.

RATE_LIMIT denotes a mitigation decision only; this pipeline does not measure successful
network mitigation. Every identical prediction result is retained. Pairwise records report
exact prediction equality, probability equality, disagreement counts and maximum probability
differences. Shared labels or strong simulated traffic signals can legitimately yield equal
decisions from different feature sets. Prediction equality is not evidence of identical models.
The deployment artifact is the last chronological fold; earlier folds use earlier canonical
fits, so aggregate agreement is with the corresponding fold baseline, not a retrospectively
applied final model that has trained on earlier test periods.
